from bottle import route, run, static_file, post, request
import time

@route('/')
def server_static (filepath = "index.html") :
	return static_file (filepath, root = './')

@post ('/login.html')
def process ():
	usr_name = request.forms.get ('usr_name')
	usr_password = request.forms.get ('usr_password')
	print("dfgijeroihjwe")
	# return "{0}{1}".format (usr_name, usr_password)
	return "<h1>ok</h1>"

run (host = 'localhost', port = 8080, debug = True, reloader = True)